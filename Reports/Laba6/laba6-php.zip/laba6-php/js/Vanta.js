VANTA.HALO({
    el: "#Main",
    mouseControls: true,
    touchControls: true,
    gyroControls: false,
    minHeight: 200.00,
    minWidth: 200.00,
    baseColor: 0x6a11cb,
    backgroundColor: 0x000000,
    amplitudeFactor: 1.50,
    size: 1.10
})