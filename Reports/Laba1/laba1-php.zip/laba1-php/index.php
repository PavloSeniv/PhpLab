<?php
header("Location: ../Task/create.php");
exit();
